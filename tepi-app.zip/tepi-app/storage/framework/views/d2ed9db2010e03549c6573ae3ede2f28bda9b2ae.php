<img src="<?php echo e($image); ?>" alt="Deskripsi gambar"
    class="h-full max-w-sm object-cover object-center border border-gray-200 rounded-lg shadow" />
<?php /**PATH C:\xampp\htdocs\Project-TEPI\tepi-app\resources\views/components/picture-card.blade.php ENDPATH**/ ?>