<?php

// $booking_data = json_decode($booking_data, true);
// var_dump($booking_data);
// $picture = $room_data['picture'];
?>


<div class="w-full p-5 flex justify-center items-center justify-items-center">
    <div class="flex gap-10 h-fit w-fit">
        <div class=" flex-1 min-w-96">
            <?php if (isset($component)) { $__componentOriginal1624da6c844f4e0baee07da390f276198cec000e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PictureCard::class, ['image' => $booking_data['student']['avatar']]); ?>
<?php $component->withName('picture-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1624da6c844f4e0baee07da390f276198cec000e)): ?>
<?php $component = $__componentOriginal1624da6c844f4e0baee07da390f276198cec000e; ?>
<?php unset($__componentOriginal1624da6c844f4e0baee07da390f276198cec000e); ?>
<?php endif; ?>
        </div>
        <div class="ps-5 flex-1 min-w-96">
            <h1 class="text-primary font-poppins font-bold text-2xl ">Identity</h1>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md w-16">Name</p>
                <p class="text-primary font-poppins font-semibold text-md "> :
                    <?php echo e($booking_data['student']['name']); ?></p>
            </div>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md w-16">NIM</p>
                <p class="text-primary font-poppins font-semibold text-md "> :
                    <?php echo e($booking_data['student']['NIM']); ?></p>
            </div>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md w-16">Email</p>
                <p class="text-primary font-poppins font-semibold text-md "> :
                    <?php echo e($booking_data['student']['email']); ?></p>
            </div>
            <h1 class="text-primary font-poppins font-bold text-2xl pt-5">Room</h1>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md "><?php echo e($booking_data['rooms']['title']); ?>

                </p>
            </div>
            <h1 class="text-primary font-poppins font-bold text-2xl pt-5">Datetime</h1>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md w-16">Date</p>
                <p class="text-primary font-poppins font-semibold text-md "> :
                    <?php echo e($booking_data['booking']['date']); ?></p>
            </div>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md w-16">Start</p>
                <p class="text-primary font-poppins font-semibold text-md "> :
                    <?php echo e($booking_data['booking']['time_start']); ?></p>
            </div>
            <div class="flex">
                <p class="text-primary font-poppins font-semibold text-md w-16">End</p>
                <p class="text-primary font-poppins font-semibold text-md "> :
                    <?php echo e($booking_data['booking']['time_end']); ?></p>
            </div>
            <h1 class="text-primary font-poppins font-bold text-2xl pt-5">Group Access</h1>


            <ul class="space-y-1 text-primary font-poppins font-semibold text-md list-disc list-inside">
                <?php $__currentLoopData = $booking_data['group_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($group); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>



            <form action="/room/confirm" method="post">
                <?php echo csrf_field(); ?>
                <div class="flex gap-5 w-full">

                    <button type="button" onclick="window.location='<?php echo e(route('home_page')); ?>'"
                        class="text-primary border-primary hover:bg-blue-300 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center border dark:text-blue-600 dark:hover:text-primary dark:focus:ring-blue-700 mt-5 w-full">Cancle</button>


                    <button type="submit"
                        class="text-white bg-primary hover:bg-blue-700 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center  dark:bg-blue-600 dark:hover:bg-primary dark:focus:ring-blue-700 mt-5 w-full">Confirm</button>

                </div>
        </div>
<?php /**PATH C:\xampp\htdocs\Project-TEPI\tepi-app\resources\views/room_confirmation.blade.php ENDPATH**/ ?>