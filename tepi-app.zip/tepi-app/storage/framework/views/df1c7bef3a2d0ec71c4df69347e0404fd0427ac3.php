<?php $__env->startComponent('components.Card'); ?>
<div class="card">
    <div class="card-header">Judul Card</div>
    <div class="card-body">
        <p>Konten Card</p>
    </div>
</div>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Project-TEPI\tepi-app\resources\views/components/Card.blade.php ENDPATH**/ ?>