<div class="min-w-64 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
    <a href="#">
        <img class="rounded-t-lg h-64 object-cover" src="<?php echo e($pic); ?>" alt="" />
    </a>
    <div class="p-5">
        <a href="#">
            <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white truncate max-w-52">
                <?php echo e($status); ?><?php echo e($title); ?>

            </h5>
        </a>
        <?php if($status == true): ?>
            <span
                class="inline-flex items-center bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-red-900 dark:text-red-300">
                <span class="w-2 h-2 me-1 bg-red-500 rounded-full"></span>
                Unavailable
            </span>
        <?php else: ?>
            <span
                class="inline-flex items-center bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-green-900 dark:text-green-300">
                <span class="w-2 h-2 me-1 bg-green-500 rounded-full"></span>
                Available
            </span>
        <?php endif; ?>

        <div class="flex gap-3 py-3">

            <?php sort($facility);
            
            // $uniqueFacilities = [];
            
            // // Sementara hapus duplikat
            // foreach ($facility as $facility_row) {
            //     if (!in_array($facility_row, $uniqueFacilities)) {
            //         $uniqueFacilities[] = $facility_row;
            //     }
            // }
            
            // $uniqueFacilities = [];
            // foreach ($facility as $facility_row) {
            //     $found = false;
            //     foreach ($uniqueFacilities as $uniqueFacility) {
            //         if ($facility_row['category'] == $uniqueFacility['category']) {
            //             $found = true;
            //             break;
            //         }
            //     }
            //     if (!$found) {
            //         $uniqueFacilities[] = $facility_row;
            //     }
            // }
            
            ?>

            
            <?php if(count($facility) <= 4): ?>
                <?php $__currentLoopData = $facility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FeatureBadge::class, ['logo' => ''.e($fac).'']); ?>
<?php $component->withName('feature-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366)): ?>
<?php $component = $__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366; ?>
<?php unset($__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php for($i = 0; $i <= 2; $i++): ?>
                    <?php if (isset($component)) { $__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FeatureBadge::class, ['logo' => ''.e($facility[$i]).'']); ?>
<?php $component->withName('feature-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366)): ?>
<?php $component = $__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366; ?>
<?php unset($__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366); ?>
<?php endif; ?>
                <?php endfor; ?>
                <?php if (isset($component)) { $__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\FeatureBadge::class, ['logo' => ''.e('+' . (count($facility) - 3)).'']); ?>
<?php $component->withName('feature-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366)): ?>
<?php $component = $__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366; ?>
<?php unset($__componentOriginalf34b2097218ae418e1f1e349589f70460f7c0366); ?>
<?php endif; ?>
            <?php endif; ?>



        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Project-TEPI\tepi-app\resources\views/components/card.blade.php ENDPATH**/ ?>