<img src="{{ $image }}" alt="Deskripsi gambar"
    class="h-full max-w-sm object-cover object-center border border-gray-200 rounded-lg shadow" />
