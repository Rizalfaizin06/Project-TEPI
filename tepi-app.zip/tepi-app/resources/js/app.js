require("./bootstrap");
import "flowbite";
import Alpine from "alpinejs";
window.Alpine = Alpine;

Alpine.start();
